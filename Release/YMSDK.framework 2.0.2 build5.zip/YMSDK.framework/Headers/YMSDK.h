#define YMSDK_VERSION @"2.0.2"

#pragma mark - Libraries

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

typedef void (^Action)(void);

#pragma mark - Configuration

#define YMSDK_APP_KIND 2
#define YMSDK_DOMAIN @"www.1996yx.com"
#define YMSDK_URL_SCHEMES_ROOTDOMAIN @"1996yx.com"
#define URI_API_ENTRY @"https://api.1996yx.com/Action/193/GetSDKParam"

@interface YMConfiguration : NSObject
{
    @package
    __strong NSString *_aid;
    __strong NSString *_appId;
    __strong NSString *_appKey;
    __strong NSString *_scheme;
    __strong NSString *_apiHostUri;
    __strong NSString *_webHostUri;
    __strong UIImage *_iconLight;
    __strong UIImage *_iconGray;
    NSInteger _timeout;
}

- (NSString * _Nonnull)appId;
- (NSString * _Nonnull)appUrlScheme;
- (NSString * _Nonnull)appUrlSchemeChildDomain;
- (void)setAppUrlSchemeChildDomain:(NSString * __nonnull)scheme;

- (NSInteger)timeout;
- (void)setTimeout:(NSInteger)sec;

- (instancetype _Nonnull)initWithAppId: (NSString * __nonnull) appId andAppKey: (NSString * __nonnull) appKey;
- (instancetype _Nonnull)initWithAppId: (NSString * __nonnull) appId andAppKey: (NSString * __nonnull) appKey andScheme: (NSString * __nonnull) scheme;

@end

#pragma mark - Entry

@interface YMSDK : NSObject{
    @package
    __strong NSString *_token;
    __strong NSString *_openid;
    __strong NSString *_lsid;
    __strong NSDictionary *_realname;
    __strong YMConfiguration *_config;
}
+ (YMSDK* _Nonnull)shared;

@end

#pragma mark - 接入入口配置
@interface YMSDK(Initialize)

- (int)initWithConfig:(YMConfiguration *__nonnull)config andApplication:(UIApplication *_Nonnull)application didFinishLaunchingWithOptions:(NSDictionary *_Nonnull)launchOptions;
- (YMConfiguration * _Nullable) configuration;

@end

#pragma mark - 账号
@interface YMSDK(Account)
- (int)auth; //平台账号登录
- (NSString * _Nullable)openId; //平台账号授权的唯一用户身份标识符
- (NSString * _Nullable)latestServerId; //该账号最近一次登录的区服ID，如果未登录过区服则为nil
- (NSDictionary * _Nullable)realnameInfo; //用户实名信息
- (NSDictionary * _Nullable)claims; //不可用，保留字段
- (BOOL)isInvalidRealname; //获取一个值，该值反映当前登录的用户是否未进行实名
- (int)exit; //退出登录
@end

#pragma mark - 角色信息上报
@interface YMSDK(Character) //在充值、角色信息上报之前必须先调用角色登录上报
- (NSString * _Nonnull)characterIdByUid:(NSString * _Nonnull)uid andServerId:(NSString * _Nonnull)serverId; //玩家角色登录上报. serverId: 服务器名称， uid: 玩家角色的uid
- (int)reportAsyncByCharacterId:(NSString * _Nonnull)characterId updateName:(NSString * _Nonnull)name andLevel:(NSString *_Nonnull)level; //玩家角色信息上报. name: 玩家角色的名称, level：玩家角色的等级

@end

#pragma mark - 充值

@interface YMSDK(Payment)
- (int)paymentByCharacterId:(NSString * _Nonnull)characterId price:(NSInteger)price title:(NSString * _Nonnull)title  description:(NSString * _Nullable)description forOrderId:(NSString * _Nonnull)oid;
//充值接口 -characterId: `characterIdByUid:andServerId` 获取的角色ID -oid: 游戏CP维护的订单号， -price：单价（单位为分）, -title：商品标题（如600元宝）， -description： 商品描述文本信息（可以为空）
@end


#pragma mark - 通知
#define YMSDKDidInitializeNotification (NSNotificationName)@"[YMSDK]初始化成功"
#define YMSDKWillAuthNotification (NSNotificationName)@"[YMSDK]即将打开登录界面"
#define YMSDKDidFinalAuthNotification (NSNotificationName)@"[YMSDK]完成身份认证"
#define YMSDKDidExitNotification (NSNotificationName)@"[YMSDK]已退出成功并回到初始状态"

#define YMSDKWillOpenPanelNotification (NSNotificationName)@"[YMSDK]用户点击悬浮球打开悬浮球界面"
#define YMSDKWillClosePanelNotification (NSNotificationName)@"[YMSDK]用户关闭悬浮球界面"

#define YMSDKDidOpenPanelNotification (NSNotificationName)@"[YMSDK]悬浮球界面已打开"
#define YMSDKDidClosePanelNotification (NSNotificationName)@"[YMSDK]悬浮球界面已关闭"

#define YMSDKWillPopupPaymentNotification (NSNotificationName)@"[YMSDK]弹出充值界面"
#define YMSDKDidCompletionPaymentNotification (NSNotificationName)@"[YMSDK]支付成功"
#define YMSDKDidCancelPaymentNotification (NSNotificationName)@"[YMSDK]支付取消"

#define YMSDKWillExitApplicationNotification (NSNotificationName)@"[YMSDK]引发错误导致app即将退出"
